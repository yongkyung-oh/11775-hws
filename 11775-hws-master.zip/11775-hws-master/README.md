# 11775-hws

Initial Steps: 
```
git clone https://github.com/11775website/11775-hws

cd /home/ubuntu
mkdir videos
sh run_download_video.sh all_video.lst ./videos
mkdir asrs
sh run_download_asr.sh all_asr.lst ./asrs
```
