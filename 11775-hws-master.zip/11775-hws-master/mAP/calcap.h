#ifndef __CALCAP_H
#define __CALCAP_H
#include <string>
#include <vector>
#include <assert.h>
float calcap(float* labels, float* rank, int len);
#endif
